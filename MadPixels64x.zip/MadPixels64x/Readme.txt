Thanks for downloading the Mad Pixels resource pack!
MadPixels By VeryMadCrafter@Planetminecraft.com
-----------
How to install:
1.Download the Mad Pixels resource pack
2.Run Minecraft
3.Click "Resource Packs"
4.Click "Open Res.Pack folder"
5.Put the Mad Pixels.zip in there
6.Select it,and play!
Strongly recommended: Turn on Fancy textures! Download MC Patcher to see additional features.
-----------
You are not allowed to use my textures without my permission.
You are allowed to make videos with my resource pack. You don`t need to ask my permission, but It`d be cool if you notify me about that.
-----------
Follow the newest versions of the Mad Pixels Pack at PlanetMinecraft.com!
If you like the pack, please support me by giving the pack a diamond at Planet Minecraft!
-----------
Want to help?
You can help me by making me a trailer/review video of this resource pack. If you decide to do so, please write me a PM at Planet Minecraft.
===========

