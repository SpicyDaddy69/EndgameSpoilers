import javax.swing.JFrame;

public class Frame extends JFrame {
	
	public Frame(String name)
	{
		JFrame frame = new JFrame(name);
		frame.setSize(1920, 1080);
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		Frame frame = new Frame("Game");
	}

}
