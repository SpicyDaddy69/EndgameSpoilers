import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Panel {

	public int y = 100;
	public int x = 100;

	public static void main(String[] arguments) {

		MyPanel panel = new MyPanel();

		// create a basic JFrame
		JFrame frame = new JFrame("JFrame Color Example");
		frame.setSize(1920, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// add panel to main frame
		frame.add(panel);

		frame.setVisible(true);

		}


}

// create a panel that you can draw on.
class MyPanel extends JPanel implements KeyListener{
	BufferedImage img;
	private int x;
	private int y;
	
	private BufferedImage currentFrame;
	
	public void paint(Graphics g) {

		loadInformations();
		currentFrame = img;
		
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, 1920, 1080);
		g.drawImage(currentFrame, getCurrentX(), getCurrentY(), null);
		
		repaint();
		
		
	}
	
	private void loadInformations() {
		try {
			img = ImageIO.read(getClass().getResource("/SlotMachine1.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public int getCurrentX()
	{
		return x;
	}
	
	public int getCurrentY()
	{
		return y;
	}
	
	
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.equals(KeyEvent.VK_W)) {
			y+=20;
			repaint();
		}
		if (e.equals(KeyEvent.VK_A)) {
			x-=20;
			repaint();
		}
		if (e.equals(KeyEvent.VK_S)) {
			y-=20;
			repaint();
		}
		if (e.equals(KeyEvent.VK_D)) {
			x+=20;
			repaint();
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}