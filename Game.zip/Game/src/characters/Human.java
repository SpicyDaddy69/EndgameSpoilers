package characters;
public class Human extends Characters {
	
	public Human(String name) {
		super(name);
		setHealth(200);
	}
}
